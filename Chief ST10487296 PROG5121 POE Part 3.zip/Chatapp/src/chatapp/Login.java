/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package chatapp;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.*;
import java.util.Properties;
/**
 *
 * @author Chief
 */

public class Login {
    private String username;
    private String password;
      private String cellphone;
    private String firstName;
    private String lastName;
private boolean loggedIn = false;
    
private static final String USER_DATA_FILE = "userdata.properties";

        public Login() {
        loadUserData();
    }

    // Check if username contains underscore and is no more than 5 characters
    public boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    // Check password complexity
    public boolean checkPasswordComplexity(String password) {
        if (password.length() < 8) {
            return false;
        }
        if (!Pattern.compile("[A-Z]").matcher(password).find()) {
            return false;
        }
        if (!Pattern.compile("[0-9]").matcher(password).find()) {
            return false;
        }
        if (!Pattern.compile("[^a-zA-Z0-9]").matcher(password).find()) {
            return false;
        }
        return true;
    }

    // Check cellphone number format
    //https://www.geeksforgeeks.org/java/program-to-check-valid-mobile-number/ website i used to form cellphone code//
    
    public boolean checkCellPhoneNumber(String cellphone) {
        Pattern pattern = Pattern.compile("^\\+27[0-9]{9}$");
        Matcher matcher = pattern.matcher(cellphone);
        return matcher.matches();
    }

    // Register user//
    // https://www.geeksforgeeks.org/java/java-program-to-check-if-two-of-three-boolean-variables-are-true website i used//
    
    public String registerUser(String username, String password, String cellphone, String firstName, String lastName) {
        StringBuilder message = new StringBuilder();
        boolean allValid = true;

        if (!checkUserName(username)) {
           message.append("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.\n");
            allValid = false;
         }

        if (!checkPasswordComplexity(password)) {
            message.append("Password is not correctly formatted, please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.\n");
           allValid = false;
        }

        if (!checkCellPhoneNumber(cellphone)) {
            message.append("Cell phone number incorrectly formatted or does not contain international code.\n");
            allValid = false;
          }

        if (allValid) {
            this.username = username;
            this.password = password;
           this.cellphone = cellphone;
           this.firstName = firstName;
            this.lastName = lastName; 
        
            saveUserData();
            
            return "User registered successfully.";
        } else {
            return message.toString();
        }
    }

        // ADD THIS METHOD to save user data after registration
private void saveUserData() {
    try {
        Properties props = new Properties();
        
        // Load existing data first
        File file = new File(USER_DATA_FILE);
        if (file.exists()) {
            try (FileInputStream in = new FileInputStream(USER_DATA_FILE)) {
                props.load(in);
            }
        }
        
        // Save current user data with username as key prefix
        String prefix = this.username + ".";
        props.setProperty(prefix + "username", this.username != null ? this.username : "");
        props.setProperty(prefix + "password", this.password != null ? this.password : "");
        props.setProperty(prefix + "cellphone", this.cellphone != null ? this.cellphone : "");
        props.setProperty(prefix + "firstName", this.firstName != null ? this.firstName : "");
        props.setProperty(prefix + "lastName", this.lastName != null ? this.lastName : "");
        
        try (FileOutputStream out = new FileOutputStream(USER_DATA_FILE)) {
            props.store(out, "User Registration Data");
        }
        System.out.println("User data saved successfully for: " + this.username);
    } catch (IOException e) {
        System.err.println("Error saving user data: " + e.getMessage());
    }
}
    
    // ADD THIS METHOD to load user data when app starts
    private void loadUserData() {
        try {
            Properties props = new Properties();
            File file = new File(USER_DATA_FILE);
            if (!file.exists()) {
                System.out.println("No previous user data found.");
                return;
            }
            
            try (FileInputStream in = new FileInputStream(USER_DATA_FILE)) {
                props.load(in);
            }
            
            this.username = props.getProperty("username", "");
            this.password = props.getProperty("password", "");
            this.cellphone = props.getProperty("cellphone", "");
            this.firstName = props.getProperty("firstName", "");
            this.lastName = props.getProperty("lastName", "");
            
            // Only consider data loaded if we have a username
            if (!this.username.isEmpty()) {
                System.out.println("User data loaded: " + this.username);
            } else {
                System.out.println("No valid user data found.");
            }
        } catch (IOException e) {
            System.err.println("Error loading user data: " + e.getMessage());
        }
    }
    
    // ADD THIS METHOD to check if a user is already registered
    public boolean isUserRegistered(String username) {
    try {
        Properties props = new Properties();
        File file = new File(USER_DATA_FILE);
        if (!file.exists()) {
            return false;
        }
        
        try (FileInputStream in = new FileInputStream(USER_DATA_FILE)) {
            props.load(in);
        }
        
        return props.getProperty(username + ".username") != null;
    } catch (IOException e) {
        return false;
    }
}
    
    
    
    // Logs in user
    // Logs in user - FIXED VERSION
public boolean loginUser(String enteredUsername, String enteredPassword) {
    try {
        Properties props = new Properties();
        File file = new File(USER_DATA_FILE);
        if (!file.exists()) {
            loggedIn = false;
            return false;
        }
        
        try (FileInputStream in = new FileInputStream(USER_DATA_FILE)) {
            props.load(in);
        }
        
        String storedUsername = props.getProperty(enteredUsername + ".username");
        String storedPassword = props.getProperty(enteredUsername + ".password");
        
        if (storedUsername != null && storedUsername.equals(enteredUsername) && 
            storedPassword != null && storedPassword.equals(enteredPassword)) {
            
            // Load user data
            this.username = storedUsername;
            this.password = storedPassword;
            this.cellphone = props.getProperty(enteredUsername + ".cellphone", "");
            this.firstName = props.getProperty(enteredUsername + ".firstName", "");
            this.lastName = props.getProperty(enteredUsername + ".lastName", "");
            
            loggedIn = true;
            return true;
        }
        
        loggedIn = false;
        return false;
    } catch (IOException e) {
        loggedIn = false;
        return false;
    }
}

    //  login status
    //https://stackoverflow.com/questions/16627910/how-to-code-a-very-simple-login-system-with-java website that i used//
   // Return login status - FIXED VERSION
public String returnLoginStatus(String enteredUsername, String enteredPassword) {
    boolean loginSuccess = loginUser(enteredUsername, enteredPassword);
    if (loginSuccess) {
        return "Welcome " + firstName + " " + lastName + " it is great to see you again.";
    } else {
        return "Username or password incorrect, please try again.";
    }
}

    // Check if user is logged in
    public boolean isLoggedIn() {
        return loggedIn;
    }
    
           
   //getters for testing// 
    
    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getCellphone() {
        return cellphone;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }
}

    
    

