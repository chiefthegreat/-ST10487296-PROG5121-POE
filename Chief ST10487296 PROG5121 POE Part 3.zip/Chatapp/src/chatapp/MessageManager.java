/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chatapp;

/**
 *
 * @author Chief
 */


import java.util.Scanner;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;
import java.nio.file.Files;

public class MessageManager {
    private List<Message> sentMessages;
    private List<Message> disregardedMessages;
    private List<Message> storedMessages;
    private List<String> messageHashes;
    private List<String> messageIDs;
    private List<Message> recentSentMessages;
    
    //constructor
    public MessageManager() {
        this.sentMessages = new ArrayList<>();
        this.disregardedMessages = new ArrayList<>();
        this.storedMessages = new ArrayList<>();
        this.messageHashes = new ArrayList<>();
        this.messageIDs = new ArrayList<>();
        this.recentSentMessages = new ArrayList<>();
    
// Load stored messages from JSON file
    loadStoredMessagesFromJSON();
    loadAllMessagesFromJSON();
}
    
public void loadTestData() {
    initializeTestData();
}
private void initializeTestData() {
  
    sentMessages.clear();
    storedMessages.clear();
    disregardedMessages.clear();
    messageHashes.clear();
    messageIDs.clear();
    recentSentMessages.clear();
    
    //Test Data Message 1 - Sent
    Message msg1 = new Message("+27834557896", "Did you get the cake?");
    addSentMessage(msg1);
    
    // Test Data Message 2 - Stored
    Message msg2 = new Message("+27838884567", "Where are you? You are late! I have asked you to be on time.");
    storedMessages.add(msg2);
    messageHashes.add(msg2.createMessage());
    messageIDs.add(msg2.getMessageID());
    
    // Test Data Message 3 - Disregarded
    Message msg3 = new Message("+27834484567", "Yohoooo, I am at your gate.");
    disregardedMessages.add(msg3);
    messageHashes.add(msg3.createMessage());
    messageIDs.add(msg3.getMessageID());
    
       // Test Data Message 4 - Sent
    Message msg4 = new Message("0838884567", "It is dinner time !");
    addSentMessage(msg4);
    
   //Test Data Message 5 - Stored
    Message msg5 = new Message("+27838884567", "Ok, I am leaving without you.");
    storedMessages.add(msg5);
    messageHashes.add(msg5.createMessage());
    messageIDs.add(msg5.getMessageID());
}
    
    public void addSentMessage(Message message) {
    sentMessages.add(message);
    recentSentMessages.add(message);
    messageHashes.add(message.createMessage());
    messageIDs.add(message.getMessageID());
    
    // Keep only last 10 recent messages
    if (recentSentMessages.size() > 10) {
        recentSentMessages.remove(0);
    }
}
    
    public void loadStoredMessagesFromJSON() {
    try {
        List<Message> jsonMessages = MessageStorage.loadStoredMessages();
        for (Message msg : jsonMessages) {
            if (!storedMessages.contains(msg)) {
                storedMessages.add(msg);
                messageHashes.add(msg.createMessage());
                messageIDs.add(msg.getMessageID());
            }
        }
    } catch (IOException e) {
        System.err.println("Error loading stored messages from JSON: " + e.getMessage());
    }
}
 public void saveAllMessagesToJSON() {
    try {
        
        StringBuilder sb = new StringBuilder();
        
        // Save sent messages
        for (Message msg : sentMessages) {
            sb.append("SENT|")
              .append(msg.getMessageID()).append("|")
              .append(msg.getRecipient()).append("|")
              .append(msg.getMessage()).append("|")
              .append(msg.getMessageNum()).append("|")
              .append(msg.createMessage()).append("\n");
        }
        
        // Save stored messages
        for (Message msg : storedMessages) {
            sb.append("STORED|")
              .append(msg.getMessageID()).append("|")
              .append(msg.getRecipient()).append("|")
              .append(msg.getMessage()).append("|")
              .append(msg.getMessageNum()).append("|")
              .append(msg.createMessage()).append("\n");
        }
        
        // Save disregarded messages
        for (Message msg : disregardedMessages) {
            sb.append("DISREGARDED|")
              .append(msg.getMessageID()).append("|")
              .append(msg.getRecipient()).append("|")
              .append(msg.getMessage()).append("|")
              .append(msg.getMessageNum()).append("|")
              .append(msg.createMessage()).append("\n");
        }
        
        // Write to file
        try (FileWriter file = new FileWriter("message_manager_data.txt")) {
            file.write(sb.toString());
            file.flush();
        }
        
        System.out.println("All messages saved to message_manager_data.txt");
        
    } catch (Exception e) {
        System.err.println("Error saving all messages: " + e.getMessage());
    }
}
    
public void loadAllMessagesFromJSON() {
    try {
        File file = new File("message_manager_data.txt");
        if (!file.exists()) {
            System.out.println("No saved message data found.");
            return;
        }
        
        // Clear existing data
        sentMessages.clear();
        storedMessages.clear();
        disregardedMessages.clear();
        messageHashes.clear();
        messageIDs.clear();
        recentSentMessages.clear();
        
        
        Scanner scanner = new Scanner(file);
        int loadedCount = 0;
        
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            String[] parts = line.split("\\|", 6); // it Split into maximum 6 parts
            
            if (parts.length >= 5) {
                String type = parts[0];
                String messageID = parts[1];
                String recipient = parts[2];
                String messageText = parts[3];
                int messageNum = Integer.parseInt(parts[4]);
                String hash = parts.length > 5 ? parts[5] : "";
                
                // to create message with predefined ID
                Message message = new Message(recipient, messageText, messageID);
                
                
                switch (type) {
                    case "SENT":
                        sentMessages.add(message);
                        recentSentMessages.add(message);
                        break;
                    case "STORED":
                        storedMessages.add(message);
                        break;
                    case "DISREGARDED":
                        disregardedMessages.add(message);
                        break;
                }
                
                // Add message to tracking lists
                messageHashes.add(message.createMessage());
                messageIDs.add(message.getMessageID());
                loadedCount++;
            }
        }
        scanner.close();
        
        // Keep only last 10 recent messages
        while (recentSentMessages.size() > 10) {
            recentSentMessages.remove(0);
        }
        
        System.out.println("Loaded " + loadedCount + " messages from save file.");
        
    } catch (Exception e) {
        System.err.println("Error loading messages: " + e.getMessage());
    }
}
    
    
    
    
    
    
    //  Display sender and recipient of all sent messages
    public String displaySentMessagesSendersRecipients() {
        StringBuilder sb = new StringBuilder();
        sb.append("Sent Messages - Senders and Recipients:\n");
        for (Message msg : sentMessages) {
            sb.append("To: ").append(msg.getRecipient())
              .append(" | Message: ").append(msg.getMessage())
              .append("\n");
        }
        return sb.toString();
    }
    
    //  Display the longest sent message
public String displayLongestSentMessage() {
    if (sentMessages.isEmpty()) {
        return "No sent messages found.";
    }
    
    // Find the  longest message from sent messages
    Message longest = null;
    for (Message msg : sentMessages) {
        if (longest == null || msg.getMessage().length() > longest.getMessage().length()) {
            longest = msg;
        }
    }
    
    if (longest != null) {
        return "Longest Sent Message:\n" +
               "Message: " + longest.getMessage() + "\n" +
               "Length: " + longest.getMessage().length() + " characters\n" +
               "Recipient: " + longest.getRecipient() + "\n" +
               "Message ID: " + longest.getMessageID();
    }
    
    return "No sent messages found.";
}
    
    //  Search for message ID and display recipient and message
   public String searchMessageByID(String messageID) {
    // Search in all arrays
    for (Message msg : sentMessages) {
        if (msg.getMessageID().equals(messageID)) {
            return "Message Found (SENT):\n" +
                   "Message ID: " + msg.getMessageID() + "\n" +
                   "Recipient: " + msg.getRecipient() + "\n" +
                   "Message: " + msg.getMessage() + "\n" +
                   "Hash: " + msg.createMessage();
        }
    }
    
    for (Message msg : storedMessages) {
        if (msg.getMessageID().equals(messageID)) {
            return "Message Found (STORED):\n" +
                   "Message ID: " + msg.getMessageID() + "\n" +
                   "Recipient: " + msg.getRecipient() + "\n" +
                   "Message: " + msg.getMessage() + "\n" +
                   "Hash: " + msg.createMessage();
        }
    }
    
    for (Message msg : disregardedMessages) {
        if (msg.getMessageID().equals(messageID)) {
            return "Message Found (DISREGARDED):\n" +
                   "Message ID: " + msg.getMessageID() + "\n" +
                   "Recipient: " + msg.getRecipient() + "\n" +
                   "Message: " + msg.getMessage() + "\n" +
                   "Hash: " + msg.createMessage();
        }
    }
    
    return "Message with ID '" + messageID + "' not found in any array.";
}
    

    //  Search for all messages sent to a particular recipient
   public String searchMessagesByRecipient(String recipient) {
    StringBuilder sb = new StringBuilder();
    sb.append("Messages for recipient: ").append(recipient).append("\n\n");
    
    boolean foundAny = false;
    
    // Search sent messages
    sb.append("SENT MESSAGES:\n");
    for (Message msg : sentMessages) {
        if (msg.getRecipient().equals(recipient)) {
            sb.append("• ").append(msg.getMessage()).append("\n");
            foundAny = true;
        }
    }
    if (!foundAny) sb.append("  No sent messages found\n");
    
    // Search stored messages  
    sb.append("\nSTORED MESSAGES:\n");
    foundAny = false;
    for (Message msg : storedMessages) {
        if (msg.getRecipient().equals(recipient)) {
            sb.append("• ").append(msg.getMessage()).append("\n");
            foundAny = true;
        }
    }
    if (!foundAny) sb.append("  No stored messages found\n");
    
    // Search disregarded messages
    sb.append("\nDISREGARDED MESSAGES:\n");
    foundAny = false;
    for (Message msg : disregardedMessages) {
        if (msg.getRecipient().equals(recipient)) {
            sb.append("• ").append(msg.getMessage()).append("\n");
            foundAny = true;
        }
    }
    if (!foundAny) sb.append("  No disregarded messages found\n");
    
    return sb.toString();
}
   
    public List<Message> getRecentSentMessagesList() {
    return new ArrayList<>(recentSentMessages);
}
    
    //  Delete a message using message hash
   public String deleteMessageByHash(String messageHash) {
    // Search and remove from sent messages
    for (int i = 0; i < sentMessages.size(); i++) {
        Message msg = sentMessages.get(i);
        if (msg.createMessage().equals(messageHash)) {
            String deletedMessage = msg.getMessage();
            sentMessages.remove(i);
            // Also remove from recent messages
            recentSentMessages.remove(msg);
            messageHashes.remove(messageHash);
            messageIDs.remove(msg.getMessageID());
            return "Message DELETED from SENT messages:\n\"" + deletedMessage + "\"";
        }
    }
    
    // Search and remove from stored messages
    for (int i = 0; i < storedMessages.size(); i++) {
        Message msg = storedMessages.get(i);
        if (msg.createMessage().equals(messageHash)) {
            String deletedMessage = msg.getMessage();
            storedMessages.remove(i);
            messageHashes.remove(messageHash);
            messageIDs.remove(msg.getMessageID());
            return "Message DELETED from STORED messages:\n\"" + deletedMessage + "\"";
        }
    }
    
    // Search and remove from disregarded messages
    for (int i = 0; i < disregardedMessages.size(); i++) {
        Message msg = disregardedMessages.get(i);
        if (msg.createMessage().equals(messageHash)) {
            String deletedMessage = msg.getMessage();
            disregardedMessages.remove(i);
            messageHashes.remove(messageHash);
            messageIDs.remove(msg.getMessageID());
            return "Message DELETED from DISREGARDED messages:\n\"" + deletedMessage + "\"";
        }
    }
    
    return "No message found with hash: " + messageHash;
}
  
    
    
    
    public String getRecentSentMessages() {
    if (recentSentMessages.isEmpty()) {
        return "No recently sent messages found.";
    }
    
    StringBuilder sb = new StringBuilder();
    sb.append("RECENTLY SENT MESSAGES\n");
    sb.append("=====================\n\n");
    
    for (int i = 0; i < recentSentMessages.size(); i++) {
        Message msg = recentSentMessages.get(i);
        sb.append("Message ").append(i + 1).append(":\n");
        sb.append("ID: ").append(msg.getMessageID()).append("\n");
        sb.append("To: ").append(msg.getRecipient()).append("\n");
        sb.append("Message: ").append(msg.getMessage()).append("\n");
        sb.append("Hash: ").append(msg.createMessage()).append("\n");
        sb.append("------------------------\n");
    }
    return sb.toString();
}
    
  // Method to simulate sending message to another user
public String sendMessageToUser(String sender, String recipient, String messageText) {
    Message message = new Message(recipient, messageText);
    
    // Validate message
    if (!message.isMessageValid()) {
        return "Message validation failed: " + message.getValidationMessage();
    }
    
    //Validate recipient
    String recipientCheck = message.checkRecipientCell();
    if (!recipientCheck.contains("successfully captured")) {
        return "Recipient validation failed: " + recipientCheck;
    }
    
    // Add to sent messages
    addSentMessage(message);
    
    return "Message sent successfully to " + recipient + 
           "\nMessage ID: " + message.getMessageID() +
           "\nMessage Hash: " + message.createMessage();
}
    
//method to display all arrays for debugging
public String displayAllArrays() {
    StringBuilder sb = new StringBuilder();
    
    sb.append("=== ALL ARRAYS STATUS ===\n\n");
    
    sb.append("SENT MESSAGES: ").append(sentMessages.size()).append(" messages\n");
    for (Message msg : sentMessages) {
        sb.append("  - To: ").append(msg.getRecipient()).append(" | ").append(msg.getMessage()).append("\n");
    }
    
    sb.append("\nSTORED MESSAGES: ").append(storedMessages.size()).append(" messages\n");
    for (Message msg : storedMessages) {
        sb.append("  - To: ").append(msg.getRecipient()).append(" | ").append(msg.getMessage()).append("\n");
    }
    
    sb.append("\nDISREGARDED MESSAGES: ").append(disregardedMessages.size()).append(" messages\n");
    for (Message msg : disregardedMessages) {
        sb.append("  - To: ").append(msg.getRecipient()).append(" | ").append(msg.getMessage()).append("\n");
    }
    
    sb.append("\nMESSAGE HASHES: ").append(messageHashes.size()).append(" hashes\n");
    for (String hash : messageHashes) {
        sb.append("  - ").append(hash).append("\n");
    }
    
    sb.append("\nMESSAGE IDs: ").append(messageIDs.size()).append(" IDs\n");
    for (String id : messageIDs) {
        sb.append("  - ").append(id).append("\n");
    }
    
    return sb.toString();
}
    
    
    //  Display report of all sent messages
    public String displaySentMessagesReport() {
    if (sentMessages.isEmpty()) {
        return "No sent messages found.";
    }
    
    StringBuilder sb = new StringBuilder();
    sb.append("COMPLETE SENT MESSAGES REPORT\n");
    sb.append("==============================\n\n");
    
    int totalChars = 0;
    for (int i = 0; i < sentMessages.size(); i++) {
         Message msg = sentMessages.get(i);
         sb.append("MESSAGE ").append(i + 1).append(":\n");
        sb.append("Message Hash: ").append(msg.createMessage()).append("\n");
         sb.append("Recipient: ").append(msg.getRecipient()).append("\n");
          sb.append("Message: ").append(msg.getMessage()).append("\n");
        sb.append("Message ID: ").append(msg.getMessageID()).append("\n");
         sb.append("Message Number: ").append(msg.getMessageNum()).append("\n");
        sb.append("Length: ").append(msg.getMessage().length()).append(" characters\n");
        sb.append("----------------------------------------\n");
        
        totalChars += msg.getMessage().length();
    }
    
    sb.append("\nSUMMARY:\n");
    sb.append("Total Sent Messages: ").append(sentMessages.size()).append("\n");
    sb.append("Total Characters Sent: ").append(totalChars).append("\n");
    sb.append("Average Message Length: ").append(totalChars / sentMessages.size()).append(" characters\n");
    
    return sb.toString();
}
    
    // Getters for unit testing
    public List<Message> getSentMessages() {
        return new ArrayList<>(sentMessages);
    }
    
    public List<Message> getDisregardedMessages() {
        return new ArrayList<>(disregardedMessages);
    }
    
    public List<Message> getStoredMessages() {
        return new ArrayList<>(storedMessages);
    }
    
    public List<String> getMessageHashes() {
        return new ArrayList<>(messageHashes);
    }
    
    public List<String> getMessageIDs() {
        return new ArrayList<>(messageIDs);
    }
    
   
    
    
}

