/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package chatapp;


/**
 *
 * @author Chief
 */




import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import java.util.List;

public class MessageManagerTest {
    private MessageManager messageManager;
    
    @Before
    public void setUp() {
        messageManager = new MessageManager();
        messageManager.loadTestData(); // Load test data for testing
    }
    
    @Test
    public void testSentMessagesArrayCorrectlyPopulated() {
        List<Message> sentMessages = messageManager.getSentMessages();
        
        // Should contain messages 1 and 4 from test data
        assertEquals("Should have 2 sent messages", 2, sentMessages.size());
        
        // Check if contains expected messages
        boolean containsMessage1 = false;
        boolean containsMessage4 = false;
        
        for (Message msg : sentMessages) {
            if ("Did you get the cake?".equals(msg.getMessage())) {
                containsMessage1 = true;
            }
            if ("It is dinner time !".equals(msg.getMessage())) {
                containsMessage4 = true;
            }
        }
        
        assertTrue("Should contain 'Did you get the cake?'", containsMessage1);
        assertTrue("Should contain 'It is dinner time!'", containsMessage4);
    }
    
    @Test
    public void testDisplayLongestMessage() {
        String longestMessage = messageManager.displayLongestSentMessage();
        
        // Should return the longest sent message
        assertTrue("Should contain longest message", 
            longestMessage.contains("Where are you? You are late! I have asked you to be on time.") ||
            longestMessage.contains("Longest Message:"));
    }
    
    @Test
    public void testSearchMessageByID() {
        // Get a message ID from the test data
        List<Message> sentMessages = messageManager.getSentMessages();
        if (!sentMessages.isEmpty()) {
            String messageID = sentMessages.get(0).getMessageID();
            String result = messageManager.searchMessageByID(messageID);
            
            assertTrue("Should find message by ID", 
                result.contains("Recipient:") || result.contains(messageID));
        }
    }
    
    @Test
    public void testSearchMessagesByRecipient() {
        String result = messageManager.searchMessagesByRecipient("+27838884567");
        
        // Should return messages 2 and 5
        assertTrue("Should contain message 2", 
            result.contains("Where are you? You are late! I have asked you to be on time."));
        assertTrue("Should contain message 5", 
            result.contains("Ok, I am leaving without you."));
        assertTrue("Should contain recipient", result.contains("+27838884567"));
    }
    
    @Test
    public void testDeleteMessageByHash() {
        // Get a message to delete
        List<Message> sentMessages = messageManager.getSentMessages();
        assertFalse("Should have sent messages to delete", sentMessages.isEmpty());
        
        Message messageToDelete = sentMessages.get(0);
        String hash = messageToDelete.createMessage();
        String messageText = messageToDelete.getMessage();
        
        String result = messageManager.deleteMessageByHash(hash);
        
        assertTrue("Should indicate successful deletion", 
            result.contains("successfully deleted"));
        assertTrue("Should mention the deleted message", 
            result.contains(messageText));
    }
    
    @Test
    public void testDisplaySentMessagesReport() {
        String report = messageManager.displaySentMessagesReport();
        
        assertTrue("Should contain report header", 
            report.contains("SENT MESSAGES REPORT"));
        assertTrue("Should contain Message Hash", 
            report.contains("Message Hash"));
        assertTrue("Should contain Recipient", 
            report.contains("Recipient"));
        assertTrue("Should contain Message", 
            report.contains("Message"));
    }
}