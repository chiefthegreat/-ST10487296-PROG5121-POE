/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package chatapp;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
/**
 *
 * @author Chief
 */

public class Login {
    private String username;
    private String password;
      private String cellphone;
    private String firstName;
    private String lastName;

    public Login() {
    }

    // Check if username contains underscore and is no more than 5 characters
    public boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    // Check password complexity
    public boolean checkPasswordComplexity(String password) {
        if (password.length() < 8) {
            return false;
        }
        if (!Pattern.compile("[A-Z]").matcher(password).find()) {
            return false;
        }
        if (!Pattern.compile("[0-9]").matcher(password).find()) {
            return false;
        }
        if (!Pattern.compile("[^a-zA-Z0-9]").matcher(password).find()) {
            return false;
        }
        return true;
    }

    // Check cellphone number format
    //https://www.geeksforgeeks.org/java/program-to-check-valid-mobile-number/ website i used to form cellphone code//
    
    public boolean checkCellPhoneNumber(String cellphone) {
        Pattern pattern = Pattern.compile("^\\+27[0-9]{9}$");
        Matcher matcher = pattern.matcher(cellphone);
        return matcher.matches();
    }

    // Register user//
    // https://www.geeksforgeeks.org/java/java-program-to-check-if-two-of-three-boolean-variables-are-true website i used//
    
    public String registerUser(String username, String password, String cellphone, String firstName, String lastName) {
        StringBuilder message = new StringBuilder();
        boolean allValid = true;

        if (!checkUserName(username)) {
           message.append("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.\n");
            allValid = false;
         }

        if (!checkPasswordComplexity(password)) {
            message.append("Password is not correctly formatted, please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.\n");
           allValid = false;
        }

        if (!checkCellPhoneNumber(cellphone)) {
            message.append("Cell phone number incorrectly formatted or does not contain international code.\n");
            allValid = false;
          }

        if (allValid) {
            this.username = username;
            this.password = password;
           this.cellphone = cellphone;
           this.firstName = firstName;
            this.lastName = lastName;
            return "User registered successfully.";
        } else {
            return message.toString();
        }
    }

    // Logs in user
    public boolean loginUser(String enteredUsername, String enteredPassword) {
        return enteredUsername.equals(this.username) && enteredPassword.equals(this.password);
    }

    //  login status
    //https://stackoverflow.com/questions/16627910/how-to-code-a-very-simple-login-system-with-java website that i used//
    public String returnLoginStatus(String enteredUsername, String enteredPassword) {
        if (loginUser(enteredUsername, enteredPassword)) {
            return "Welcome " + firstName + "," + lastName + " it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }

   //getters for testing// 
    
    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getCellphone() {
        return cellphone;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }
}

    
    

