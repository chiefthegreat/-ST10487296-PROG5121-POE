/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package chatapp;



import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class MessageIT {
    
    private Message message;
    
    @Before
    public void setUp() {
       
        Message.resetMessageCounter();
       
        message = new Message("0123456789", "Hello World");
    }

    @Test
    public void testMessageCreation() {
        assertNotNull("Message should be created", message);
        assertEquals("Recipient should match", "0123456789", message.getRecipient());
        assertEquals("Message text should match", "Hello World", message.getMessage());
    }

    @Test
    public void testMessageID() {
        String messageID = message.getMessageID();
        assertNotNull("Message ID should not be null", messageID);
        assertEquals("Message ID should be 10 digits", 10, messageID.length());
        
        boolean isValid = message.checkMessageID();
        assertTrue("Message ID should be valid", isValid);
    }

    @Test
    public void testRecipientValidation() {
  
        Message localMessage = new Message("0123456789", "Test");
        String localResult = localMessage.checkRecipientCell();
        assertEquals("Local number should be valid", 
                     "Cell phone number successfully captured.", localResult);
        
        // Test valid international number
        Message intlMessage = new Message("+27123456789", "Test");
        String intlResult = intlMessage.checkRecipientCell();
        assertEquals("International number should be valid", 
                     "Cell phone number successfully captured.", intlResult);
        
        // Test invalid number
        Message invalidMessage = new Message("1123456789", "Test");
        String invalidResult = invalidMessage.checkRecipientCell();
        assertTrue("Invalid number should return error", 
                   invalidResult.contains("incorrectly formatted"));
    }

    @Test
    public void testMessageHash() {
        String hash = message.createMessage();
        assertNotNull("Hash should not be null", hash);
        assertTrue("Hash should contain colons", hash.contains(":"));
        
        
        
        assertTrue("Hash should contain HELLO and WORLD", 
                   hash.contains("HELLO") && hash.contains("WORLD"));
    }

    @Test
    public void testMessageValidation() {
        // Test valid message
        String validResult = message.getValidationMessage();
        assertEquals("Valid message should be ready to send", 
                     "Message ready to send.", validResult);
        
        assertTrue("Valid message should pass validation", message.isMessageValid());
        
        // Test long message
        String longText = "A".repeat(300);
        Message longMessage = new Message("0123456789", longText);
        String longResult = longMessage.getValidationMessage();
        assertTrue("Long message should be rejected", longResult.contains("exceeds"));
        
        assertFalse("Long message should fail validation", longMessage.isMessageValid());
    }

    @Test
    public void testMessageCounter() {
        
        assertEquals(1, message.getMessageNum());
        
        
        Message secondMessage = new Message("0123456789", "Second message");
        assertEquals(2, secondMessage.getMessageNum());
        
        // Check total messages
        assertEquals(2, Message.returnTotalMessages());
    }
}