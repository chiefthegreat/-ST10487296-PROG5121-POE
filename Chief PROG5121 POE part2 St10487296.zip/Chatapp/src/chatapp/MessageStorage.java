/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chatapp;

/**
 *
 * @author Chief
 */


import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class MessageStorage {
    private static final String STORAGE_FILE = "stored_messages.json";
    private static final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public static void storeMessage(Message message) throws IOException {
        List<Message> storedMessages = loadStoredMessages();
        storedMessages.add(message);
        saveStoredMessages(storedMessages);
    }

    public static List<Message> loadStoredMessages() throws IOException {
        File file = new File(STORAGE_FILE);
        if (!file.exists()) {
            return new ArrayList<>();
        }
        
        try (FileReader reader = new FileReader(STORAGE_FILE)) {
            Type listType = new TypeToken<ArrayList<Message>>(){}.getType();
            List<Message> loadedMessages = gson.fromJson(reader, listType);
            return loadedMessages != null ? loadedMessages : new ArrayList<>();
        }
    }

    private static void saveStoredMessages(List<Message> messages) throws IOException {
        try (FileWriter writer = new FileWriter(STORAGE_FILE)) {   //https://www.geeksforgeeks.org/java/try-with-resources-feature-in-java/
            gson.toJson(messages, writer);
        }
    }

    public static String getStoredMessagesAsString() {
        try {
            List<Message> messages = loadStoredMessages();
            if (messages.isEmpty()) {
                return "No stored messages found.";
            }
            
            StringBuilder sb = new StringBuilder();
            sb.append("Stored Messages (JSON):\n\n");
            for (int i = 0; i < messages.size(); i++) {
                Message msg = messages.get(i);
                sb.append("Message ").append(i + 1).append(":\n");
                sb.append("ID: ").append(msg.getMessageID()).append("\n");
                sb.append("Hash: ").append(msg.createMessage()).append("\n");
                sb.append("To: ").append(msg.getRecipient()).append("\n");
                sb.append("Text: ").append(msg.getMessage()).append("\n\n");
            }
            return sb.toString();
        } catch (IOException e) {
            return "Error loading stored messages: " + e.getMessage();
        }
    }
}
