/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chatapp;

//@ author chief

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Message {
    private static int totalMessages = 0;
    private static List<Message> sentMessages = new ArrayList<>();
    private String messageID;
    private String recipient;
    private String message;
    private int messageNum;

    
    
    public Message(String recipient, String message) {
        this.recipient = recipient;
        this.message = message;
        this.messageNum = ++totalMessages;
        this.messageID = generateMessageID();
    }

    // https://docs.oracle.com/javase/8/docs/api/java/util/Random.html 
    private String generateMessageID() {
        Random rand = new Random();
        StringBuilder id = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            id.append(rand.nextInt(10));
        }
        return id.toString();
    }

    public boolean checkMessageID() {
        return messageID != null && messageID.length() == 10;
    }

    
    public String checkRecipientCell() {
        if (recipient == null || recipient.trim().isEmpty()) {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
        
        String cleanRecipient = recipient.trim();
        
       
        if (cleanRecipient.startsWith("0") && cleanRecipient.length() <= 10 && cleanRecipient.matches("^0[0-9]{1,9}$")) {
            return "Cell phone number successfully captured.";
        }
        
      
        if (cleanRecipient.startsWith("+") && cleanRecipient.length() <= 13 && cleanRecipient.matches("^\\+[0-9]{1,12}$")) {
            return "Cell phone number successfully captured.";
        }
        
        return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
    }

    public String createMessage() {
        if (message == null || message.trim().isEmpty()) {
            return messageID.substring(0, 2) + ":" + messageNum + ":EMPTY";
        }
        
        
        //https://docs.oracle.com/javase/8/docs/api/java/lang/String.html
        //https://docs.oracle.com/javase/8/docs/api/java/lang/String.html#split-java.lang.String-
        String[] words = message.trim().split("\\s+");
        if (words.length == 0) {
            return messageID.substring(0, 2) + ":" + messageNum + ":EMPTY";
        }
        
        String firstWord = words[0].toUpperCase();
        String lastWord = words[words.length - 1].toUpperCase();
        
        return messageID.substring(0, 2) + ":" + messageNum + ":" + firstWord + lastWord;
    }

    //https://docs.oracle.com/javase/8/docs/api/javax/swing/JOptionPane.html
    public String sendMessage() {
        String[] options = {"Send Message", "Disregard Message", "Store Message"};
        int choice = JOptionPane.showOptionDialog(null, "Choose an option:",
                "Message Options", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,
                null, options, options[0]);

        switch (choice) {
            case 0:
                sentMessages.add(this);
                return "Message successfully sent.";
            case 1:
                return "Press 0 to delete message.";
            case 2:
                storeMessage();
                return "Message successfully stored.";
            default:
                return "No action taken.";
        }
    }

    public void storeMessage() {
        // JSON storage implementation
        try {
            MessageStorage.storeMessage(this);
            JOptionPane.showMessageDialog(null, "Message successfully stored in JSON file.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error storing message: " + e.getMessage());
        }
    }

    public String printMessages() {
        StringBuilder sb = new StringBuilder();
        for (Message msg : sentMessages) {
            sb.append(msg.toString()).append("\n\n");
        }
        return sb.toString();
    }

    public static int returnTotalMessages() {
        return totalMessages;
    }

    // Message validation for 250 characters
    public String getValidationMessage() {
        if (message == null || message.trim().isEmpty()) {
            return "Message cannot be empty.";
        }
        if (message.length() > 250) {
            int excess = message.length() - 250;
            return "Message exceeds 250 characters by " + excess + ", please reduce size.";
        }
        return "Message ready to send.";
    }

    public boolean isMessageValid() {
        return message != null && message.length() <= 250 && !message.trim().isEmpty();
    }

    // Getters
    public String getMessageID() {
        return messageID;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessage() {
        return message;
    }

    public int getMessageNum() {
        return messageNum;
    }

    public static List<Message> getSentMessages() {
        return new ArrayList<>(sentMessages);
    }

    public static void resetMessageCounter() {
        totalMessages = 0;
        sentMessages.clear();
    }

    @Override
    public String toString() {
        return "Message ID: " + messageID +
               "\nMessage Hash: " + createMessage() +
               "\nRecipient: " + recipient +
               "\nMessage: " + message +
               "\nMessage Number: " + messageNum;
    }
    
}