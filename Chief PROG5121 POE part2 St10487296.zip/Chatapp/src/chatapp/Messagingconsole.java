/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chatapp;

//@ author chief

import javax.swing.*;

public class Messagingconsole {
    private Login login;
    private int maxMessages = 0;
    private int messagesSent = 0;

    public Messagingconsole(Login login) {
        this.login = login;
    }

    public void startMessaging() {
        // to check if thee user is logged in
        if (!login.isLoggedIn()) {
            JOptionPane.showMessageDialog(null, "Please login first to access messaging.");
            return;
        }

        
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat.");

        // Get number of messages from user
        String messageCountStr = JOptionPane.showInputDialog("How many messages do you wish to send?");
        try {
            maxMessages = Integer.parseInt(messageCountStr);
            if (maxMessages <= 0) {
                JOptionPane.showMessageDialog(null, "Please enter a positive number.");
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid number entered.");
            return;
        }

        // Main menu loop
        //https://www.w3schools.com/java/java_while_loop.asp
        boolean running = true;
        while (running && messagesSent < maxMessages) {
            String choice = showMenu();
            
            if (choice == null) {
                // User closed the dialog
                running = false;
                continue;
            }
            
            //https://www.programiz.com/java-programming/switch-statement
            switch (choice) {
                case "1":
                   sendMessageFlow();
                    break;
              case "2": 
                   showRecentMessages();
                    break;
             case "3": 
                   showStoredMessages();
                    break;
               case "4": // Quit
                    running = false;
                    showExitSummary();
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid option. Please try again.");
            }
        }
        
      
        if (messagesSent >= maxMessages) {
            JOptionPane.showMessageDialog(null, 
                "You have reached your message limit of " + maxMessages + " messages.\n" +
                "Total messages sent: " + messagesSent);
        }
    }

    private String showMenu() {
        String menu = "QuickChat Menu\n" +
                     "Messages sent: " + messagesSent + "/" + maxMessages + "\n\n" +
                     "Please choose an option:\n" +
                     "1) Send Messages\n" +
                     "2) Show recently sent messages\n" +
                     "3) Show stored messages\n" +
                     "4) Quit";
        
        return JOptionPane.showInputDialog(null, menu, "QuickChat", 
                                          JOptionPane.QUESTION_MESSAGE);
    }

    private void sendMessageFlow() {
        if (messagesSent >= maxMessages) {
            JOptionPane.showMessageDialog(null, 
                "You have reached your message limit of " + maxMessages + " messages.");
            return;
        }

       // Get recipient
          String recipient = JOptionPane.showInputDialog("Enter recipient cellphone number:");
        if (recipient == null) return;

        // Validate recipient
        Message tempMessage = new Message(recipient, "test");
         String recipientValidation = tempMessage.checkRecipientCell();
        if (!recipientValidation.contains("successfully captured")) {
          JOptionPane.showMessageDialog(null, recipientValidation);
            return;
        }

        // Get message
        String messageText = JOptionPane.showInputDialog("Enter your message (max 250 characters):");
        if (messageText == null) return; 
        
     
        Message message = new Message(recipient, messageText.trim());
        String validationResult = message.getValidationMessage();
        
        if (!validationResult.equals("Message ready to send.")) {
            JOptionPane.showMessageDialog(null, validationResult);
            return;
        }


        String result = message.sendMessage();
        JOptionPane.showMessageDialog(null, result);

      
        if (result.equals("Message successfully sent.")) {
            messagesSent++;
            showMessageDetails(message);
        }
       
    }

   private void showRecentMessages() {
    JOptionPane.showMessageDialog(null, "Coming Soon.");
}

    private void showStoredMessages() {
        String storedMessages = MessageStorage.getStoredMessagesAsString();
        JOptionPane.showMessageDialog(null, storedMessages);
    }

    private void showMessageDetails(Message message) {
        String details = "Message Sent Successfully!\n\n" +
                        "Message ID: " + message.getMessageID() + "\n" +
                   "Message Hash: " + message.createMessage() + "\n" +
                    "Recipient: " + message.getRecipient() + "\n" +
                     "Message: " + message.getMessage() + "\n\n" +
                        "Total messages sent this session: " + messagesSent + "/" + maxMessages;
        
        JOptionPane.showMessageDialog(null, details);
    }

    private void showExitSummary() {
        String summary = "Thank you for using QuickChat!\n\n" +
              "Session Summary:\n" +
              "Total messages sent: " + messagesSent + "\n" +
                 "Message limit: " + maxMessages + "\n" +
                    "Messages remaining: " + (maxMessages - messagesSent) + "\n" +
                        "Overall total messages: " + Message.returnTotalMessages();
        
        JOptionPane.showMessageDialog(null, summary);
    }
}
