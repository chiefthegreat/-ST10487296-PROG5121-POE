/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package chatapp;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.DisplayName;

public class LoginTest {

    @Test
    public void testCheckUserNameCorrectlyFormatted() {
        Login login = new Login();
        assertTrue(login.checkUserName("kyl_1"), "Username should be correctly formatted");
    }

    @Test
    @DisplayName("Invalid username with symbols should fail")
    public void testCheckUserNameIncorrectlyFormatted() {
        Login login = new Login();
        assertFalse(login.checkUserName("kyle!!!!!!!"), "Username should be incorrectly formatted");
    }

    @Test
    public void testCheckPasswordComplexityMeetsRequirements() {
        Login login = new Login();
        assertTrue(login.checkPasswordComplexity("Ch&&sec@ke99!"), "Password should meet complexity requirements");
    }

    @Test
    public void testCheckPasswordComplexityDoesNotMeetRequirements() {
        Login login = new Login();
        assertFalse(login.checkPasswordComplexity("password"), "Password should not meet complexity requirements");
    }

    @Test
    public void testCheckCellPhoneNumberCorrectlyFormatted() {
        Login login = new Login();
        assertTrue(login.checkCellPhoneNumber("+27838968976"), "Cell phone number should be correctly formatted");
    }

    @Test
    public void testCheckCellPhoneNumberIncorrectlyFormatted() {
        Login login = new Login();
        assertFalse(login.checkCellPhoneNumber("08966553"), "Cell phone number should be incorrectly formatted");
    }

    @Test
    public void testLoginSuccessful() {
        Login login = new Login();
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Smith");
        assertTrue(login.loginUser("kyl_1", "Ch&&sec@ke99!"), "Login should be successful");
    }

    @Test
    public void testLoginFailed() {
        Login login = new Login();
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Smith");
        assertFalse(login.loginUser("wronguser", "wrongpass"), "Login should fail");
    }

    @Test
    public void testReturnLoginStatusSuccessful() {
        Login login = new Login();
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Smith");
        assertEquals("Welcome Kyle,Smith it is great to see you again.",
                     login.returnLoginStatus("kyl_1", "Ch&&sec@ke99!"),
                     "Login status should be successful");
    }

    @Test
    public void testReturnLoginStatusFailed() {
        Login login = new Login();
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Smith");
        assertEquals("Username or password incorrect, please try again.",
                     login.returnLoginStatus("wronguser", "wrongpass"),
                     "Login status should be failed");
    }

    @Test
    public void testRegisterUserSuccess() {
        Login login = new Login();
        assertEquals("User registered successfully.",
                     login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Smith"),
                     "User should be registered successfully");
    }

    @Test
    public void testRegisterUserUsernameFailure() {
        Login login = new Login();
        assertEquals("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.\n",
                     login.registerUser("kyle!!!!!!!", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Smith"),
                     "Username should fail validation");
    }

    @Test
    public void testRegisterUserPasswordFailure() {
        Login login = new Login();
        assertEquals("Password is not correctly formatted, please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.\n",
                     login.registerUser("kyl_1", "password", "+27838968976", "Kyle", "Smith"),
                     "Password should fail validation");
    }

    @Test
    public void testRegisterUserCellphoneFailure() {
        Login login = new Login();
        assertEquals("Cell phone number incorrectly formatted or does not contain international code.\n",
                     login.registerUser("kyl_1", "Ch&&sec@ke99!", "08966553", "Kyle", "Smith"),
                     "Cellphone should fail validation");
    }

}

//https://www.geeksforgeeks.org/software-testing/unit-testing-software-testing/  website i used to code the login test//