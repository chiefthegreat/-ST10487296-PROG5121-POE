/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author Chief
 */

package chatapp;

import javax.swing.*;
  import java.awt.*;

public class GUI extends JFrame {
    private JTextField usernameField, cellphoneField, firstNameField, lastNameField;
    private JPasswordField passwordField, loginPasswordField;
    private JTextField loginUsernameField;
    private JTextArea outputArea;
    private Login login;

    public GUI() {
        login = new Login();
        setTitle("ChiefChatApp");
        setSize(500, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        // Header
        JLabel header = new JLabel("ChiefChat", SwingConstants.CENTER);
       header.setFont(new Font("SansSerif", Font.BOLD, 22));
        header.setBorder(BorderFactory.createEmptyBorder(15, 0, 10, 0));
        add(header, BorderLayout.NORTH);

        // Tabs
        JTabbedPane tabs = new JTabbedPane();

        // Registration Panel
        JPanel registerPanel = new JPanel();
    registerPanel.setLayout(new BoxLayout(registerPanel, BoxLayout.Y_AXIS));
        registerPanel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));

        usernameField = new JTextField(20);
    passwordField = new JPasswordField(20);
        cellphoneField = new JTextField(20);
     firstNameField = new JTextField(20);
        lastNameField = new JTextField(20);

     registerPanel.add(createLabeledField("Username:", usernameField));
        registerPanel.add(createLabeledField("Password:", passwordField));
       registerPanel.add(createLabeledField("Cellphone:", cellphoneField));
    registerPanel.add(createLabeledField("First Name:", firstNameField));
       registerPanel.add(createLabeledField("Last Name:", lastNameField));

       JButton registerButton = new JButton("Register");
        registerButton.setAlignmentX(Component.CENTER_ALIGNMENT);
       registerPanel.add(Box.createVerticalStrut(10));
        registerPanel.add(registerButton);

        tabs.addTab("Register", registerPanel);

        // Login Panel
        JPanel loginPanel = new JPanel();
        loginPanel.setLayout(new BoxLayout(loginPanel, BoxLayout.Y_AXIS));
        loginPanel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));

        loginUsernameField = new JTextField(20);
        loginPasswordField = new JPasswordField(20);

        loginPanel.add(createLabeledField("Username:", loginUsernameField));
        loginPanel.add(createLabeledField("Password:", loginPasswordField));

        JButton loginButton = new JButton("Login");
        loginButton.setAlignmentX(Component.CENTER_ALIGNMENT);
       loginPanel.add(Box.createVerticalStrut(10));
        loginPanel.add(loginButton);

        tabs.addTab("Login", loginPanel);

        add(tabs, BorderLayout.CENTER);

       // Output Area
        outputArea = new JTextArea(5, 40);
       outputArea.setEditable(false);
       outputArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
       outputArea.setBorder(BorderFactory.createTitledBorder("Status"));
        add(new JScrollPane(outputArea), BorderLayout.SOUTH);

        // Button Actions
        registerButton.addActionListener(e -> {
            String username = usernameField.getText().trim();
           String password = new String(passwordField.getPassword()).trim();
           String cellphone = cellphoneField.getText().trim();
            String firstName = firstNameField.getText().trim();
            String lastName = lastNameField.getText().trim();

        if (username.isEmpty() || password.isEmpty() || cellphone.isEmpty() || firstName.isEmpty() || lastName.isEmpty()) {
                outputArea.setForeground(Color.RED);
                outputArea.setText("Please fill in all registration fields.");
                return;
            }

            String result = login.registerUser(username, password, cellphone, firstName, lastName);
            outputArea.setForeground(Color.BLUE);
            outputArea.setText("Registration Result:\n" + result);
        });

        loginButton.addActionListener(e -> {
            String enteredUsername = loginUsernameField.getText().trim();
            String enteredPassword = new String(loginPasswordField.getPassword()).trim();

            if (enteredUsername.isEmpty() || enteredPassword.isEmpty()) {
                outputArea.setForeground(Color.RED);
                outputArea.setText("Please enter both username and password.");
                return;
            }

            String status = login.returnLoginStatus(enteredUsername, enteredPassword);
            outputArea.setForeground(status.toLowerCase().contains("success") ? Color.GREEN : Color.RED);
            outputArea.setText("Login Status:\n" + status);
        });

        setVisible(true);
    }

    private JPanel createLabeledField(String labelText, JComponent field) {
        JPanel panel = new JPanel(new BorderLayout(5, 5));
     JLabel label = new JLabel(labelText);
       label.setPreferredSize(new Dimension(100, 25));
       panel.add(label, BorderLayout.WEST);
        panel.add(field, BorderLayout.CENTER);
        panel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        return panel;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(GUI::new);
    }
}

//https://www.geeksforgeeks.org/java/java-swing-simple-user-registration-form/ website i used to form the code//



